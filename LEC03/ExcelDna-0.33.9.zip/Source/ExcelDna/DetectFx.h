#pragma once

bool DetectFxIsNet20Installed();
int  DetectFxReadMajorVersion(TCHAR* pszVersion);
